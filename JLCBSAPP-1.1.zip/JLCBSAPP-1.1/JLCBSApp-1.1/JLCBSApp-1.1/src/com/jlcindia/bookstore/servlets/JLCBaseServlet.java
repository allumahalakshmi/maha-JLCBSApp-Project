package com.jlcindia.bookstore.servlets;

import javax.servlet.http.HttpServlet;

import com.jlcindia.bookstore.controllers.ChangePWController.*;
import com.jlcindia.bookstore.controllers.ForgotPWController.*;
import com.jlcindia.bookstore.controllers.LoginController.*;
import com.jlcindia.bookstore.controllers.RegisterController.*;
import com.jlcindia.bookstore.controllers.UpdateProfileController.*;


public abstract class JLCBAseServlet extends HttpServlet{
	
	static LoginController loginController;
	static RegisterController registerController;
	static ChangePWController changePWController;
	static ForgotPWController forgotPWController;
	static UpdateProfileController updateProfileController;
	static LogoutController logoutController;
	
	static {
		loginController = new LoginController();
		registerController = new RegisterController();
		chnagePWController = new ChangePWController();
		forgotPWController = new ForgotPWController();
		updateProfileController = new UpdateProfileController();
		logoutController = new LogoutController();
		
		
	}
	
	
	
}