package com.coursecube.bookstore.controller;

import javax.servlet.http.*;
public class LogoutController extends JLCBaseController{
public String process(HttpServletRequest req,HttpServletResponse res) throws Exception{
System.out.println("LogoutController-process()");
String page="index.jsp";
HttpSession session=req.getSession(false);
if(session!=null)
session.invalidate();
String logoutMsg="You have logged out Successfully";
req.setAttribute("LogoutMsg", logoutMsg);
return page;
}
}

